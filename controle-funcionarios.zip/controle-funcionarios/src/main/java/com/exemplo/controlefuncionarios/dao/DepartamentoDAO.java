package com.exemplo.controlefuncionarios.dao;

import com.exemplo.controlefuncionarios.entidades.Departamento;

public class DepartamentoDAO extends GenericDAO<Departamento> {
}